package exception;

public class ByerException extends Exception{
    public ByerException() {
    }

    public ByerException(String message) {
        super(message);
    }
}
