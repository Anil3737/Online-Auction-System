package exception;

public class CredentialException extends Exception {
    public CredentialException() {
    }

    public CredentialException(String message) {
        super(message);
    }
}
