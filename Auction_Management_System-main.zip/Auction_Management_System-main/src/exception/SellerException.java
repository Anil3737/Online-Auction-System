package exception;

public class SellerException extends Exception{
    public SellerException() {
    }

    public SellerException(String message) {
        super(message);
    }
}
